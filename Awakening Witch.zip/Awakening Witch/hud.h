#ifndef HUD_H
#define HUD_H
#include "resource.h"

void hud_init(void);
void hud_draw(void);
#endif