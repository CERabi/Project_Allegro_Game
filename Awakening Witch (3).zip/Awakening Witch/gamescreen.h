#ifndef GAME_H
#define GAME_H
#include <allegro5/allegro_primitives.h>
#include "init.h"
#include "object.h"

void gamescreen(void);
#endif