#ifndef HUD_H
#define HUD_H
#include "resource.h"
#include "object.h"

void hud_init(void);
void hud_draw(void);
#endif